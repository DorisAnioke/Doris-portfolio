import React from 'react'

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2025 Doris Anioke. All rights reserved.</p>
    </footer>
  )
}

export default Footer
